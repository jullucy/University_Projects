package publicTransport;

/**
 * Class representing tram lines.
 */
public class TramLine extends Line {
    public TramLine(int number, int numberOfTrams, int lengthOfRoute) {
        super(number, numberOfTrams, lengthOfRoute);
    }
}